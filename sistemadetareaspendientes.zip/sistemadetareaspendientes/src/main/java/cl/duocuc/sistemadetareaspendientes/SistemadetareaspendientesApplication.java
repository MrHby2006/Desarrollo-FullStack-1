package cl.duocuc.sistemadetareaspendientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemadetareaspendientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemadetareaspendientesApplication.class, args);
	}

}
