package cl.duocuc.sistemadetareaspendientes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.sistemagestionproductos.model.Tarea;
import cl.duocuc.sistemagestionproductos.repository.TareaRepository;

@Service
public class TareaService {
    @Autowired
    private TareaRepository tareaRepository;

    public List<Tarea> getTarea(){
        return tareaTepository.mostrarTarea();
    }

    public void addTarea(Tarea tarea){
        tareaRepository.agreagarTarea(tarea);
    }

    public boolean deleteTarea(int id){
        return tareaRepository.eliminarTarea(id);
    }
}
