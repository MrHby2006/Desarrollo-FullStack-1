package cl.duocuc.sistemadetareaspendientes.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import cl.duocuc.sistemagestionproductos.model.Tarea;

@Repository
public class TareaRepository {
    private List<Tarea> listaTareas = new ArrayList<>();
}

public List<Tarea> mostrarTarea{
    return listaTareas;
}

public void agregarTarea(Tarea tarea){
    listaTareas.add(tarea);
}

public boolean eliminarTarea(int id){
    return listaTareas.removeIf(tarea -> tarea.getId().equals(id));
}