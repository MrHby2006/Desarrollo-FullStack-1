package cl.duocuc.sistemadetareaspendientes.controller;

@RestController
@RequestMapping("api/v1/tareas")
public class TareaController {
    @Autowired
    private TareaService tareaService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Tarea> mostrarTareas(){
        return tareaService.getTarea();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void agregarTarea(@RequestBody @Valid Tarea tarea){
        tareaService.addTarea(tarea)
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> eliminarTarea(@PathVariable int id){
        if (tareaService.deleteTarea(id)){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.notFound().build();
        }
    }
}
