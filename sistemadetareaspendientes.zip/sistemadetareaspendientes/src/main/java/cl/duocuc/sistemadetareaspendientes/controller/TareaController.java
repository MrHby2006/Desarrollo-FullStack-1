package cl.duocuc.sistemadetareaspendientes.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.sistemadetareaspendientes.model.Tarea;
import cl.duocuc.sistemadetareaspendientes.service.TareaService;

@RestController
@RequestMapping("api/v1/tareas")
public class TareaController {
    @Autowired
    private TareaService tareaService;

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Tarea> mostrarTareas(){
        return tareaService.getTarea();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public void agregarTarea(@RequestBody @Validated Tarea tarea){
        tareaService.addTarea(tarea);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Boolean> eliminarTarea(@PathVariable int id){
        if (tareaService.deleteTarea(id)){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.notFound().build();
        }
    }
}
