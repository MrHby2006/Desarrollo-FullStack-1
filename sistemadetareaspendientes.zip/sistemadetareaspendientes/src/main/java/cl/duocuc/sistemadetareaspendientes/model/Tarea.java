package cl.duocuc.sistemadetareaspendientes.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@Data
@NoArgsConstructor
public class Tarea {
    private int id;
    private String nombre;
    private boolean estado;
}
