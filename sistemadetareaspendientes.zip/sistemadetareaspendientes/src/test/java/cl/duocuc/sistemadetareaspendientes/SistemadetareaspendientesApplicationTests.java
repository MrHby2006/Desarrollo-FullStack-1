package cl.duocuc.sistemadetareaspendientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemadetareaspendientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
