package cl.hospital.hospital_vm.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.hospital.hospital_vm.Model.Atencion;
import cl.hospital.hospital_vm.Service.AtencionService;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("api/v1/atenciones")
public class AtencionController {
    @Autowired
    private AtencionService service;

    @GetMapping
    public ResponseEntity<List<Atencion>> listarAtenciones(){
        List<Atencion> listaAtenciones = service.mostrarAtenciones();

        if (listaAtenciones.isEmpty()){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(listaAtenciones);
        }
    }

    @PostMapping
    public void guardar(@RequestBody Atencion atencion){
        service.guardarAtencion(atencion);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Atencion> buscarPorId(Integer id){
        try{
            Atencion atencion = service.buscarPorId(id);
            return ResponseEntity.ok(atencion);
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(Integer id){
        try{
            service.eliminarAtencion(id);
            return ResponseEntity.noContent().build();
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/paciente/{IdPaciente}")
    public ResponseEntity<List<Atencion>> buscarAtencionPorPaciente(Integer idPaciente){
        List<Atencion> atenciones = service.buscarAtencionPorIdPaciente(idPaciente);

        if(atenciones.isEmpty()){
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(atenciones);
        }
    }
}
