package cl.hospital.hospital_vm.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.hospital.hospital_vm.Model.Paciente;
import cl.hospital.hospital_vm.Service.PacienteService;

@RestController
@RequestMapping("/api/v1/paciente")
public class PacienteController {
    @Autowired
    private PacienteService service;

    @GetMapping
    public Paciente buscarId(@PathVariable Long id){
        return service.buscarPorId(id);
    }

    @GetMapping
    public List<Paciente> mostrarTodos(){
        return service.mostrarTodos();
    }

    @GetMapping("/{correo}")
    public Paciente buscarPorCorreo(String correo){
        return service.buscarPorCorreo(correo);
    }

    @GetMapping("/{nombre}")
    public List<Paciente> buscarPorNombre(String nombre){
        return service.buscarPorNombre(nombre);
    }

    @PostMapping
    public void guardarPaciente(@RequestBody Paciente paciente){
        service.guardarPaciente(paciente);
    }

    @DeleteMapping("/{id}")
    public void borrarPaciente(Long id){
        service.eliminar(id);
    }
}
