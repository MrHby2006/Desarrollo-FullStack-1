package cl.hospital.hospital_vm.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.hospital.hospital_vm.Model.Atencion;

@Repository
public interface AtencionRepository extends JpaRepository<Atencion, Integer>{
    public List<Atencion> findByPacienteId(Integer id);
}
