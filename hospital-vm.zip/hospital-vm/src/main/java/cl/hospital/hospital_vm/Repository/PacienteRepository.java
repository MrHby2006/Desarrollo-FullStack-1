package cl.hospital.hospital_vm.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.hospital.hospital_vm.Model.Paciente;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long>{
    Paciente findByCorreo(String correo);

    List<Paciente> findByNombre(String nombre);
}