package cl.hospital.hospital_vm.Model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "atencion")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Atencion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private Date fechaAtencion;

    @Column(nullable = false)
    private String diagnostico;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "paciente_id", nullable = false)
    private Paciente paciente;

    //@ManyToOne : Define la relacion que tendra en la base de datos respecto al objeto tipo Paciente.
    //FetchType.EAGER -> Nos permite trabajas con el objeto y todos sus datos y no solo el id.
    //@JoinColumn : Crea una tabla en la base de datos para guardar el id(pk) del paciente.
}
