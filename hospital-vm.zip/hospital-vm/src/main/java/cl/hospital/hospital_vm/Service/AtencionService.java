package cl.hospital.hospital_vm.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.hospital.hospital_vm.Model.Atencion;
import cl.hospital.hospital_vm.Repository.AtencionRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class AtencionService {
    @Autowired
    private AtencionRepository repo;

    public List<Atencion> mostrarAtenciones(){
        return repo.findAll();
    }

    public void guardarAtencion(Atencion atencion){
        repo.save(atencion);
    }

    public Atencion buscarPorId(Integer id){
        return repo.findById(id).get();
    }

    public void eliminarAtencion(Integer id){
        repo.deleteById(id);
    }

    public List<Atencion> buscarAtencionPorIdPaciente(Integer id){
        return repo.findByPacienteId(id);
    }
}
