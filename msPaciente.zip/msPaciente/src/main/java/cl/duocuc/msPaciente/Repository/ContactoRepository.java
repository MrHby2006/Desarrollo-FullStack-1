package cl.duocuc.msPaciente.Repository;

@Repository
public interface ContactoRepository extends JpaRepository<Contacto, Integer> {
    Optional<Contacto> findByPacienteId(Integer id);
}
