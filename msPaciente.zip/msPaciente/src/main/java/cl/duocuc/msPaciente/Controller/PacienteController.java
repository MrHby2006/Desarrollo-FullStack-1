package cl.duocuc.msPaciente.Controller;

@RestController
@RequestMapping("/api/v1/pacientes")
public class PacienteController {
    @Autowired
    private PacienteService service;

    @GetMapping
    public List<Paciente> listaPacientes listar() {
        List<Paciente> listaPacientes = service.getAllPacientes();
        if (listaPacientes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.ok(listaPacientes);
        }
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<Paciente> obtenerPacientePorId(@PathVariable Integer id) {
        try {
            Paciente paciente = service.getPacienteById(id);
            return ResponseEntity.ok(paciente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @getMapping("/rut/{rut}")
    public ResponseEntity<Paciente> obtenerPacientePorRut(@PathVariable String rut) {
        try {
            Paciente paciente = service.getPacienteByRut(rut);
            return ResponseEntity.ok(paciente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public Paciente guardarPaciente(@RequestBody Paciente paciente) {
        Paciente nuevoPaciente = service.savePaciente(paciente);
        return ResponseEntity.ok(nuevoPaciente);
    }

    @PutMapping("/id/{id}")
    public ResponseEntity<Paciente> actualizarPaciente(@PathVariable Integer id, @RequestBody Paciente paciente) {
        try {
            Paciente pacienteActualizado = service.updatePaciente(id, paciente);
            return ResponseEntity.ok(pacienteActualizado);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> eliminarPaciente(@PathVariable Integer id) {
        try {
            service.deletePaciente(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}