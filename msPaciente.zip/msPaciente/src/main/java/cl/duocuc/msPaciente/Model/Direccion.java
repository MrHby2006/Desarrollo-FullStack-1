package cl.duocuc.msPaciente.Model;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "direccion")
public class Direccion {

    @Id
    @GeneratedValue(startegy = GenerationType.IDENTITY)
    private Integer id;
    
    @Column(nullable = false)
    private String calle;

    @Column(nullable = false)
    private String numero;

    @Column(nullable = false)
    private String ciudad;

    @Column(nullable = false)
    private String comuna;

    @OnoToOne
    @JoinColumn(name ="paciente_id")
    private Paciente paciente;
}
