package cl.duocuc.msPaciente.Model;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "paciente")
public class Paciente {

    @Id
    @GeneartedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String run;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false)
    private String apellido;

    @Column(nullable = false)
    private String edad;

    @OnoToOne(mappedBy = "paciente", cascade = CascadeType.ALL)
    @JoinColumn(name ="contacto_id")
    private Contacto contacto;

    @OnoToOne(mappedBy = "paciente", cascade = CascadeType.ALL)
    @JoinColumn(name ="direccion_id")
    private Direccion direccion;
}
