package cl.duocuc.msPaciente.Model;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "contacto")
public class Contacto {

    @Id
    @GeneartedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String telefono;

    @Column(nullable = false)
    private String correo;

    @OneToOne
    @JoinColumn(name = "paciente_id")
    private Paciente paciente;
}
