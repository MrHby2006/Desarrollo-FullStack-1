package cl.duocuc.msPaciente.Service;

@Service
public class PacienteService {
    @Autowired
    private PacienteRepository repo;

    public List<Paciente> listaPacientes() {
        return repo.findAll();
    }

    public Paciente buscarPorId(Integer id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
    }

    public Paciente buscarPorRut(String rut) {
        return repo.findByRut(rut).orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
    }
    
    public void eliminarPaciente(Integer id) {

        if(repo.existsById(id)){
            repo.deleteById(id);
        } else {
            throw new RuntimeException("Paciente no encontrado");
        }
    }

    public Paciente guardarPaciente(Paciente paciente) {
        if(paciente.getDireccion() != null){
            paciente.getDireccion().setPaciente(paciente);
        }
        if(paciente.getContacto() != null){
            paciente.getContacto().setPaciente(paciente);
        }
        return repo.save(paciente);
    }

    public Paciente actualizarPaciente(Integer id, Paciente paciente) {
        Paciente pacienteAnt = repo.findById(id).orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
        pacienteAnt.setNombre(pacienteActualizado.getNombre());
        pacienteAnt.setApellido(pacienteActualizado.getApellido());
        pacienteAnt.setEdad(pacienteActualizado.getEdad());

        if(pacienteActualizado.getDireccion() != null){
            pacienteActualizado.getDireccion().setPaciente(pacienteAnt);
            pacienteAnt.setDireccion(pacienteActualizado.getDireccion());
        }

        if(pacienteActualizado.getContacto() != null){
            pacienteActualizado.getContacto().setPaciente(pacienteAnt);
            pacienteAnt.setContacto(pacienteActualizado.getContacto());
        }
        return repo.save(pacienteAnt);
    }
}
