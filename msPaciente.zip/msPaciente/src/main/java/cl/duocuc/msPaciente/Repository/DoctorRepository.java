package cl.duocuc.msPaciente.Repository;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Integer> {
    Optional<Doctor> findByRut(String rut);
}
