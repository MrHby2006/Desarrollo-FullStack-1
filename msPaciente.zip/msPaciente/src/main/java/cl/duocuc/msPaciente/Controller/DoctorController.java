package cl.duocuc.msPaciente.Controller;

@RestController
@RequestMapping("/api/v1/doctores")
public class DoctorController {
    @Autowired
    private DoctorService service;

    @GetMapping
    public List<Doctor> listaDoctores listar() {
        List<Doctor> listaDoctores = service.listaDoctores();
        if (listaDoctores.isEmpty()) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.ok(listaDoctores);
        }
    }

    @GetMapping("/id/{id}")
    public ResponseEntity<Doctor> obtenerDoctorPorId(@PathVariable Integer id) {
        try {
            Doctor doctor = service.buscarPorId(id);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/rut/{rut}")
    public ResponseEntity<Doctor> obtenerDoctorPorRut(@PathVariable String rut) {
        try {
            Doctor doctor = service.buscarPorRut(rut);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public Doctor guardarDoctor(@RequestBody Doctor doctor) {
        Doctor nuevoDoctor = service.guardarDoctor(doctor);
        return ResponseEntity.ok(nuevoDoctor);
    }

    @PutMapping("/id/{id}")
    public ResponseEntity<Doctor> actualizarDoctor(@PathVariable Integer id, @RequestBody Doctor doctor) {
        try {
            Doctor doctorActualizado = service.actualizarDoctor(id, doctor);
            return ResponseEntity.ok(doctorActualizado);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/id/{id}")
    public ResponseEntity<Void> eliminarDoctor(@PathVariable Integer id) {
        try {
            service.eliminarDoctor(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}