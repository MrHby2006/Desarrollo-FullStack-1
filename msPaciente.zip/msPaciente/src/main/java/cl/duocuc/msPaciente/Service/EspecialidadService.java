package cl.duocuc.msPaciente.Service;

@Service
public class EspecialidadService {

}
