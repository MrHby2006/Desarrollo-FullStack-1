package cl.duocuc.msPaciente.Repository;

@Repository
public interface EspecialidadRepository extends JpaRepository<Especialidad, Integer> {
    Optional<Especialidad> findByDoctorId(Integer id);
}
