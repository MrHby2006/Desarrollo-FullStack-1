package cl.duocuc.msPaciente.Repository;

@Repository
public interface DireccionRepository extends JpaRepository<Direccion, Integer> {
    Optional<Direccion> findByPacienteId(Integer id);

}
