package cl.duocuc.pruebacarritoyproducto.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.pruebacarritoyproducto.Model.Producto;
import cl.duocuc.pruebacarritoyproducto.Service.ProductoService;

@RestController
@RequestMapping("/api/v1/producto")
public class ProductoController {
    @Autowired
    private ProductoService service;

    @GetMapping
    public List<Producto> mostrarTodos(){
        return service.mostrarProductos();
    }

    @PostMapping
    public void guardar(@RequestBody Producto producto){
        service.guardarProducto(producto);
    }

    @DeleteMapping("/{id}")
    public void borrarProducto(Long id){
        service.eliminarProducto(id);
    }

    @GetMapping
    public Producto buscarId(@PathVariable Long id){
        return service.buscarPorId(id);
    }

    @GetMapping("/{nombre}")
    public List<Producto> buscarPorNombre(String nombre){
        return service.buscarPorNombre(nombre);
    }
}
