package cl.duocuc.pruebacarritoyproducto.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.pruebacarritoyproducto.Repository.ProductoRepository;
import cl.duocuc.pruebacarritoyproducto.Repository.CarritoRepository;
import jakarta.transaction.Transactional;

@Transactional
@Service
public class CarritoService {
    @Autowired
    private CarritoRepository repo;
    
    @Autowired
    private ProductoRepository productoRepo;

    public void agregarProducto(Long productoId) {
        Producto p = productoRepo.findById(productoId)
            .orElseThrow(() -> new RuntimeException("Producto no encontrado"));
        
        Carrito item = new Carrito();
        item.setProducto(p);
        repo.save(item);
    }

    public void eliminarDelCarrito(Integer idCarrito) {
        repo.deleteById(idCarrito);
    }

    public Integer calcularTotal() {
        List<Carrito> items = repo.findAll();
        return items.stream()
                    .mapToInt(item -> item.getProducto().getPrecio())
                    .sum();
    }

    public void vaciarCarrito() {
        repo.deleteAll();
    }
}
