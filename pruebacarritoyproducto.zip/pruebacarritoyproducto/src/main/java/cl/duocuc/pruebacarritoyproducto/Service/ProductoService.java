package cl.duocuc.pruebacarritoyproducto.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.pruebacarritoyproducto.Model.Producto;
import cl.duocuc.pruebacarritoyproducto.Repository.ProductoRepository;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class ProductoService {
    @Autowired
    private ProductoRepository repo;

    public List<Producto> mostrarProductos(){
        return repo.findAll();
    }

    public void guardarProducto(Producto producto){
        repo.save(producto);
    }

    public void eliminarProducto(Long id){
        repo.deleteById(id);
    }

    public List<Producto> buscarPorNombre(String nombre){
        return repo.findByNombre(nombre);
    }

    public Producto buscarPorId(Long id){
        return repo.findById(id).get();
    }
}
