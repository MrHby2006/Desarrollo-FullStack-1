package cl.duocuc.pruebacarritoyproducto.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.pruebacarritoyproducto.Service.CarritoService;

@RestController
@RequestMapping("/api/v1/carrito")
public class CarritoController {
    @Autowired
    private CarritoService service;

    @PostMapping("/agregar/{productoId}")
    public void agregar(@PathVariable Long productoId) {
        service.agregarProducto(productoId);
    }

    @DeleteMapping("/eliminar/{idCarrito}")
    public void eliminar(@PathVariable Integer idCarrito) {
        service.eliminarDelCarrito(idCarrito);
    }

    @GetMapping("/total")
    public Integer obtenerTotal() {
        return service.calcularTotal();
    }

    @PostMapping("/pagar")
    public String pagar() {
        Integer total = service.calcularTotal();
        service.vaciarCarrito();
        return "Pago realizado con éxito. Total: $" + total;
    }
}
