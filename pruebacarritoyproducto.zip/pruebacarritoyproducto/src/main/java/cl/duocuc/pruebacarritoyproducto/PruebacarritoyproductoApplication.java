package cl.duocuc.pruebacarritoyproducto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebacarritoyproductoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebacarritoyproductoApplication.class, args);
	}

}
