package cl.duocuc.pruebacarritoyproducto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duocuc.pruebacarritoyproducto.Model.Producto;

@Repository
public interface ProductoRepository extends JpaRepository<Producto, Long>{

}
