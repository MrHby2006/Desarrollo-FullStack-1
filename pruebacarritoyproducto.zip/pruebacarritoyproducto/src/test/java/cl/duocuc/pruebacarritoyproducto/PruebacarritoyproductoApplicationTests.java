package cl.duocuc.pruebacarritoyproducto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebacarritoyproductoApplicationTests {

	@Test
	void contextLoads() {
	}

}
