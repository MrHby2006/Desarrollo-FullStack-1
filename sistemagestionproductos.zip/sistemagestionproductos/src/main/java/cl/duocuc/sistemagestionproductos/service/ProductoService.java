package cl.duocuc.sistemagestionproductos.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.sistemagestionproductos.model.Producto;
import cl.duocuc.sistemagestionproductos.repository.ProductoRepository;

@Service
public class ProductoService {
    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> getProducto(){
        return productoRepository.mostrarProductos();
    }

    public void addProducto(Producto producto){
        productoRepository.agregarProducto(producto);
    }

    public boolean deleteProducto(String nombre){
        return productoRepository.eliminarProducto(nombre);
    }
}
