package cl.duocuc.sistemagestionproductos.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import cl.duocuc.sistemagestionproductos.model.Producto;

@Repository
public class ProductoRepository {
    public ProductoRepository(){
        listaProductos.add(new Producto("CocaCola", 1900, "alimento"));
        listaProductos.add(new Producto("Arroz", 990, "alimento"));
    }

    private List<Producto> listaProductos = new ArrayList<>();

    public List<Producto> mostrarProductos(){
        return listaProductos;
    }

    public void agregarProducto(Producto producto){
        listaProductos.add(producto);
    }

    public boolean eliminarProducto(String nombre){
        return listaProductos.removeIf(producto -> producto.getNombre().equals(nombre));
    }
}
