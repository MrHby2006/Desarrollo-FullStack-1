package cl.duocuc.msAtencion.Model;

import java.util.Date;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table
@Schema(description = "Representa una atención dentro del sistema")
public class Atencion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Id unico de la atención", example = "1")
    private Integer id;

    @Column(nullable = false)
    @Schema(description = "Nombre del diagnostico de la atención", example = "Dolor estomacal")
    private String diagnostico;

    @Column(nullable = false)
    @Schema(description = "Fecha de la atención", example = "22/09/2026")
    private Date fechaAtencion;

    @ManyToOne
    @JoinColumn(name = "tipo_atencion_id", nullable = false)
    @Schema(description = "Tipo de atención correspondiente", example = "urgencias")
    private TipoAtencion tipoAtencion;

    @Column(name = "paciente_id", nullable = false)
    @Schema(description = "Datos del paciente de la atención, esta información se entrega gracias a que este microservicio llama a otro para que le de esta información")
    private Integer pacienteId;

    @Column(name = "doctor_id", nullable = false)
    @Schema(description = "Datos del doctor de la atención, esta información se entrega gracias a que este microservicio llama a otro para que le de esta información")
    private Integer doctorId;
}
