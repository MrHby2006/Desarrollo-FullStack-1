package cl.duocuc.msAtencion.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import cl.duocuc.msAtencion.dto.PacienteDTO;

// FeignClient
// Removimos el atributo 'url' para que se use el descubrimiento dinamico
// OpenFeign buscara el nombre 'ms_pacientes' registrados en el Servidor Eureka
@FeignClient(name = "msPaciente", url = "http://localhost:8081")
public interface PacienteCliente {

    // Este metodo representa una llamada HTTP GET dinamica
    //
    // Equivale a resolver dinamicamente:
    // GET http://[IP_EUREKA_PACIENTE]:[PUERTO_EUREKA_PACIENTE]/api/v1/pacientes/dto/{id}  
    //
    //
    @GetMapping("/api/v1/pacientes/dto/{id}")
    PacienteDTO getPacienteDTO(@PathVariable ("id") Integer id);
}
