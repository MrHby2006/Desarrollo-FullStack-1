package cl.duocuc.msAtencion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient
@SpringBootApplication
@EnableFeignClients(basePackages = "cl.duocuc.msAtencion.Client")
public class MsAtencionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAtencionApplication.class, args);
	}

}
