package cl.duocuc.msAtencion;

public @interface EnableFeignClientsS {

}
