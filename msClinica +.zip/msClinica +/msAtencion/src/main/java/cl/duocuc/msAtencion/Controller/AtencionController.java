package cl.duocuc.msAtencion.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.msAtencion.Model.Atencion;
import cl.duocuc.msAtencion.Service.AtencionService;
import cl.duocuc.msAtencion.dto.AtencionDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RequestMapping("/api/v1/atencion")
@RestController
@Tag(name = "Atenciones", description = "Operaciones sobre las atenciones")
public class AtencionController {
    @Autowired
    private AtencionService service;

    @GetMapping
    @Operation(summary = "Retona la lista completa de atenciones")
    public ResponseEntity<List<Atencion>> getAll() {
        List<Atencion> atenciones = service.getAll();

        if(atenciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.ok(atenciones);
        }
    }

    @PostMapping
    @Operation(summary = "Registrar un nuevo paciente")
    public ResponseEntity<Atencion> save(@RequestBody Atencion atencion) {
        try{
            service.save(atencion);
            return ResponseEntity.ok(atencion);
        }catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar en atención por ID", description = "Retorna una atención segun el ID proporcionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Atención encontrado"),
                            @ApiResponse(responseCode = "404", description = "Atención no encontrado"),
                            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<Atencion> buscarPorId(@RequestAttribute Integer id) {
        try{
            Atencion atencion = service.getById(id);
            return ResponseEntity.ok(atencion);
        }catch(Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/atencionCompleta/{id}")
    @Operation(summary = "Buscar en atenciónDTO por ID", description = "Retorna una atención con todos los datos segun el ID proporcionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Atención encontrado"),
                            @ApiResponse(responseCode = "404", description = "Atención no encontrado"),
                            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<AtencionDTO> buscarAtencionCompleta(@PathVariable Integer id){
        try{
            return ResponseEntity.ok(service.buscarAtencionDTO(id));
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
