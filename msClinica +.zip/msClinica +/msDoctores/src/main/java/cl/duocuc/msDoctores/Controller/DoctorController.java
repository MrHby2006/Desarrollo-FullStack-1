package cl.duocuc.msDoctores.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.msDoctores.Model.Doctor;
import cl.duocuc.msDoctores.Service.DoctorService;
import cl.duocuc.msDoctores.dto.DoctorDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("api/v1/doctores")
@Tag(name = "Doctores", description = "Operaciones sobre doctores")
public class DoctorController {
    @Autowired
    private DoctorService service;

    @GetMapping
    @Operation(summary = "Retona la lista completa de doctores")
    public ResponseEntity<List<Doctor>> listarDoctores() {
        List<Doctor> doctores = service.listaDoctores();
        
        if(doctores.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(doctores);
        }
    }

    @GetMapping("/dto/{id}")
    @Operation(summary = "Retorna un doctorDTO segun el ID proporcionado", description = "Metodo que permite retonar un doctor dto, normalmente se usa cuando otro microservicio del sistema necesita datos de un doctor")
    public ResponseEntity<DoctorDTO> buscarDTO(@PathVariable Integer id) {
        try {
            Doctor doctor = service.buscarPorId(id);
            DoctorDTO doctorDTO = new DoctorDTO();
            doctorDTO.setId(doctor.getId());
            doctorDTO.setNombre(doctor.getNombre());
            doctorDTO.setEspecialidad(doctor.getEspecialidad().getNombre());
            return ResponseEntity.ok(doctorDTO);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/id")
    @Operation(summary = "Buscar en doctor por ID", description = "Retorna un doctor segun el ID proporcionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Doctor encontrado"),
                            @ApiResponse(responseCode = "404", description = "Doctor no encontrado"),
                            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<Doctor> buscarPorId(Integer id) {
        try {
            Doctor doctor = service.buscarPorId(id);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/rut")
    @Operation(summary = "Buscar un doctor por Rut", description = "Retorna un doctor segun el Rut proporcionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Doctor encontrado"),
                            @ApiResponse(responseCode = "404", description = "Doctor no encontrado"),
                            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<Doctor> buscarPorRut(String rut) {
        try {
            Doctor doctor = service.buscarPorRut(rut);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/id")
    @Operation(summary = "Elimina a un doctor por ID", description = "Elimina del sistema un doctor con solo poner su ID")
    public ResponseEntity<Void> eliminarDoctor(Integer id) {
        try {
            service.eliminarDoctor(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @Operation(summary = "Registrar un nuevo doctor")
    public ResponseEntity<Doctor> guardarDoctor(@RequestBody Doctor doctor) {
        Doctor nuevoDoctor = service.guardarDoctor(doctor);
        return ResponseEntity.ok(nuevoDoctor);
    }

    @PutMapping("/id")
    @Operation(summary = "Actualiza los datos de un doctor")
    public ResponseEntity<Doctor> actualizarDoctor(@PathVariable Integer id, @RequestBody Doctor doctorActualizado) {
        try {
            Doctor doctor = service.actualizarDoctor(id, doctorActualizado);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
