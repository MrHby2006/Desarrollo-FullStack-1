package cl.duocuc.msDoctores.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

import io.swagger.v3.oas.annotations.media.Schema;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "especialidad")
public class Especialidad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Id unico de la especialidad", example = "1")
    private Integer id;

    @Column(nullable = false)
    @Schema(description = "Nombre de la especialidad", example = "Geriatrico")
    private String nombre;

    @OneToMany(mappedBy = "especialidad")
    @Schema(description = "Lista de doctores a los que esta relacionado una especialidad")
    private List<Doctor> doctors;
}