package cl.duocuc.msDoctores.Model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "doctor")
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Id unico del doctor", example = "1")
    private Integer id;

    @Column(nullable = false)
    @Schema(description = "Nombre del doctor", example = "Raul")
    private String nombre;

    @Column(name = "run", nullable = false)
    @Schema(description = "ROL UNICO TRIBUTARIO del doctor, dato unico asociado al doctor", example = "12345678-9")
    private String rut;

    @ManyToOne
    @JoinColumn(name = "especialidad_id", nullable = false)
    @Schema(description = "Especialidad del doctor", example = "Traumatologo")
    private Especialidad especialidad;
}