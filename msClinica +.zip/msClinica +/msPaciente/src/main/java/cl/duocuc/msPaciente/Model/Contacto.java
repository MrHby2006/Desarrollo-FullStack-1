package cl.duocuc.msPaciente.Model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "contacto")
@Schema(description = "Representa los datos de contacto de un paciente dentro del sistema")
public class Contacto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Id unico de contacto", example = "1")
    private Integer id;

    @Column(nullable = false)
    @Schema(description = "Telefono de contacto del paciente", example = "+569 33332121")
    private String telefono;

    @Column(nullable = false)
    @Schema(description = "Correo del paciente", example = "holaestoesuncorreo@gmail.com")
    private String correo;

    @OneToOne
    @JoinColumn(name = "paciente_id")
    private Paciente paciente;
}
