package cl.duocuc.msPaciente.Model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "paciente")
@Schema(description = "Representa un paciente dentro del sistema")
public class Paciente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Id unico del paciente", example = "1")
    private Integer id;

    @Column(nullable = false)
    @Schema(description = "ROL UNICO TRIBUTARIO del paciente, dato unico asociado al paciente", example = "12345678-9")
    private String rut;

    @Column(nullable = false)
    @Schema(description = "Nombre de pila del paciente", example = "Juan")
    private String nombre;

    @Column(nullable = false)
    @Schema(description = "Apellido paterno del paciente", example = "Ramirez")
    private String apellido;

    @Column(nullable = false)
    @Schema(description = "Edad del paciente", example = "60")
    private String edad;

    @OneToOne(mappedBy = "paciente", cascade = CascadeType.ALL)
    @JoinColumn(name ="contacto_id")
    @Schema(description = "Datos de contacto del paciente, esto es una tabla aparte")
    private Contacto contacto;

    @OneToOne(mappedBy = "paciente", cascade = CascadeType.ALL)
    @JoinColumn(name ="direccion_id")
    @Schema(description = "Datos de direccion del paciente, esto es una tabla aparte")
    private Direccion direccion;
}
