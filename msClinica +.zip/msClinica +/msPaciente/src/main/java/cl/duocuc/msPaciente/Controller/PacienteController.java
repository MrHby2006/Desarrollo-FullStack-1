package cl.duocuc.msPaciente.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.msPaciente.Model.Paciente;
import cl.duocuc.msPaciente.Service.PacienteService;
import cl.duocuc.msPaciente.dto.PacienteDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/v1/pacientes")
@Tag(name = "Pacientes", description = "Operaciones sobre pacientes")
public class PacienteController {
    @Autowired
    private PacienteService service;

    @GetMapping
    @Operation(summary = "Retona la lista completa de pacientes")
    public ResponseEntity<List<Paciente>> listarPacientes(){
        List<Paciente> listaPacientes = service.listaPacientes();
        if (listaPacientes.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.ok(listaPacientes);
        }
    }

    @GetMapping("/dto/{id}")
    @Operation(summary = "Retorna un pacienteDTO segun el ID proporcionado", description = "Metodo que permite retonar un paciente dto, normalmente se usa cuando otro microservicio del sistema necesita datos de un paciente")
    public ResponseEntity<PacienteDTO> buscarDTO(@PathVariable Integer id) {
        try {
            Paciente paciente = service.buscarPorId(id);
            PacienteDTO pacienteDTO = new PacienteDTO();
            pacienteDTO.setId(paciente.getId());
            pacienteDTO.setNombre(paciente.getNombre());
            pacienteDTO.setApellido(paciente.getApellido());

            return ResponseEntity.ok(pacienteDTO);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/id/{id}")
    @Operation(summary = "Buscar en paciente por ID", description = "Retorna un paciente segun el ID proporcionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Paciente encontrado"),
                            @ApiResponse(responseCode = "404", description = "Paciente no encontrado"),
                            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<Paciente> obtenerPacientePorId(@PathVariable @Parameter(description = "Numero entero que es el ID del paciente", required = true, examples ={@ExampleObject(value = "1")}) Integer id) {
        try {
            Paciente paciente = service.buscarPorId(id);
            return ResponseEntity.ok(paciente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/rut/{rut}")
    @Operation(summary = "Buscar en paciente por Rut", description = "Retorna un paciente segun el Rut proporcionado")
    @ApiResponses(value = {@ApiResponse(responseCode = "200", description = "Paciente encontrado"),
                            @ApiResponse(responseCode = "404", description = "Paciente no encontrado"),
                            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    public ResponseEntity<Paciente> obtenerPacientePorRut(@PathVariable String rut) {
        try {
            Paciente paciente = service.buscarPorRut(rut);
            return ResponseEntity.ok(paciente);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    @Operation(summary = "Registrar un nuevo paciente")
    public ResponseEntity<Paciente> guardarPaciente(@RequestBody Paciente paciente) {
        Paciente nuevoPaciente = service.guardarPaciente(paciente);
        return ResponseEntity.ok(nuevoPaciente);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualiza los datos de un paciente")
    public ResponseEntity<Paciente> actualizarPaciente(@PathVariable Integer id, @RequestBody Paciente paciente) {
        try {
            Paciente pacienteActualizado = service.actualizarPaciente(id, paciente);
            return ResponseEntity.ok(pacienteActualizado);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Elimina a un paciente por ID", description = "Elimina del sistema un paciente con solo poner su ID")
    public ResponseEntity<Void> eliminarPaciente(@PathVariable Integer id) {
        try {
            service.eliminarPaciente(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}