package cl.duoc.sistemaregistroclientes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaregistroclientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
