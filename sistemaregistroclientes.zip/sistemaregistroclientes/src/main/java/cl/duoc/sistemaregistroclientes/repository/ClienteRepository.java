package cl.duoc.sistemaregistroclientes.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;
import cl.duoc.sistemaregistroclientes.model.Cliente;

@Repository
public class ClienteRepository {
    public List<Cliente> listaClientes = new ArrayList<>();

    public Cliente agregarCliente(Cliente cliente){
        listaClientes.add(cliente);
        return cliente;
    }

    public List<Cliente> obtenerClientes(){
        return listaClientes;
    }

    public void eliminarPorCorreo(String correo){
        listaClientes.removeIf(cliente -> cliente.getCorreo().equals(correo));
    }
}
