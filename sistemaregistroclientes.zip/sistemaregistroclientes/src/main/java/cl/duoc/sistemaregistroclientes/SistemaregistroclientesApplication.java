package cl.duoc.sistemaregistroclientes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaregistroclientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaregistroclientesApplication.class, args);
	}

}
