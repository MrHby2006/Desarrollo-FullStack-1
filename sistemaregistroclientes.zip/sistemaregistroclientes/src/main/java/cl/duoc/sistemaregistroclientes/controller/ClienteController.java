package cl.duoc.sistemaregistroclientes.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cl.duoc.sistemaregistroclientes.model.Cliente;
import cl.duoc.sistemaregistroclientes.service.ClienteService;

@RestController
@RequestMapping("api/v1/clientes")
public class ClienteController {
    @Autowired
    private ClienteService clienteService;
    
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Cliente agregarCliente(@RequestBody Cliente cliente){
        return clienteService.saveCliente(cliente);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Cliente> listarClientes(){
        return clienteService.getClientes();
    }

    @DeleteMapping("/{correo}")
    public ResponseEntity<String> eliminarCliente(@PathVariable String correo){
        int cantidadAntes = clienteService.getClientes().size();
        
        clienteService.deleteCliente(correo);
        int cantidadDespues = clienteService.getClientes().size();

        if (cantidadAntes == cantidadDespues){
            return new ResponseEntity<>("Cliente no encontrado", HttpStatus.NOT_FOUND);
        } else {
            return new ResponseEntity<>("Cliente eliminado con éxito", HttpStatus.OK);
        }
    }
}
