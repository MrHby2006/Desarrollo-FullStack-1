package cl.duoc.sistemaregistroclientes.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duoc.sistemaregistroclientes.model.Cliente;
import cl.duoc.sistemaregistroclientes.repository.ClienteRepository;

@Service
public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;

    public Cliente saveCliente(Cliente cliente){
        return clienteRepository.agregarCliente(cliente);
    }

    public List<Cliente> getClientes(){
        return clienteRepository.obtenerClientes();
    }

    public String deleteCliente(String correo){
        clienteRepository.eliminarPorCorreo(correo);
        return "cliente eliminado";
    }
}
