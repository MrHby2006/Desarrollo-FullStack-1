package cl.duocuc.msDoctores.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.msDoctores.Model.Doctor;
import cl.duocuc.msDoctores.Service.DoctorService;
import cl.duocuc.msDoctores.dto.DoctorDTO;

@RestController
@RequestMapping("api/v1/doctores")
public class DoctorController {
    @Autowired
    private DoctorService service;

    @GetMapping
    public ResponseEntity<List<Doctor>> listarDoctores() {
        List<Doctor> doctores = service.listaDoctores();
        
        if(doctores.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else{
            return ResponseEntity.ok(doctores);
        }
    }

    @GetMapping("/dto/{id}")
    public ResponseEntity<DoctorDTO> buscarDTO(@PathVariable Integer id) {
        try {
            Doctor doctor = service.buscarPorId(id);
            DoctorDTO doctorDTO = new DoctorDTO();
            doctorDTO.setId(doctor.getId());
            doctorDTO.setNombre(doctor.getNombre());
            doctorDTO.setEspecialidad(doctor.getEspecialidad().getNombre());
            return ResponseEntity.ok(doctorDTO);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/id")
    public ResponseEntity<Doctor> buscarPorId(Integer id) {
        try {
            Doctor doctor = service.buscarPorId(id);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/rut")
    public ResponseEntity<Doctor> buscarPorRut(String rut) {
        try {
            Doctor doctor = service.buscarPorRut(rut);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/id")
    public ResponseEntity<Void> eliminarDoctor(Integer id) {
        try {
            service.eliminarDoctor(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping
    public ResponseEntity<Doctor> guardarDoctor(@RequestBody Doctor doctor) {
        Doctor nuevoDoctor = service.guardarDoctor(doctor);
        return ResponseEntity.ok(nuevoDoctor);
    }

    @PutMapping("/id")
    public ResponseEntity<Doctor> actualizarDoctor(@PathVariable Integer id, @RequestBody Doctor doctorActualizado) {
        try {
            Doctor doctor = service.actualizarDoctor(id, doctorActualizado);
            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
