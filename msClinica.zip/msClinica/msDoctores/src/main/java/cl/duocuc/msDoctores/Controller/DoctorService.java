package cl.duocuc.msDoctores.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.msDoctores.Model.Doctor;
import cl.duocuc.msDoctores.Repository.DoctorRepository;

@Service
public class DoctorService {
    @Autowired
    private DoctorRepository repo;

    public List<Doctor> listaDoctores() {
        return repo.findAll();
    }

    public Doctor buscarPorId(Integer id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Doctor no encontrado"));
    }

    public Doctor buscarPorRut(String rut) {
        return repo.findByRut(rut).orElseThrow(() -> new RuntimeException("Doctor no encontrado"));
    }

    public void eliminarDoctor(Integer id) {
        if(repo.existsById(id)){
            repo.deleteById(id);
        } else {
            throw new RuntimeException("Doctor no encontrado");
        }
    }

    public Doctor guardarDoctor(Doctor doctor) {
        if(doctor.getEspecialidad() != null){
            doctor.getEspecialidad().setDoctor(doctor);
        }
        return repo.save(doctor);
    }

    public Doctor actualizarDoctor(Integer id, Doctor doctorActualizado) {
        Doctor doctorAnt = repo.findById(id).orElseThrow(() -> new RuntimeException("Doctor no encontrado"));
        doctorAnt.setNombre(doctorActualizado.getNombre());

        if(doctorActualizado.getEspecialidad() != null){
            doctorActualizado.getEspecialidad().setDoctor(doctorAnt);
            doctorAnt.setEspecialidad(doctorActualizado.getEspecialidad());
        }
        return repo.save(doctorAnt);
    }
}
