package cl.duocuc.msDoctores.Config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import cl.duocuc.msDoctores.Model.Especialidad;
import cl.duocuc.msDoctores.Repository.EspecialidadRepository;

@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner initData(EspecialidadRepository repo) {
        return args -> {
            if(repo.count() == 0){
                repo.save(new Especialidad(null, "cardiología", null));
                repo.save(new Especialidad(null, "dermatilogía", null));
                repo.save(new Especialidad(null, "neurología", null));
                repo.save(new Especialidad(null, "pediatría", null)); 
            }
        };
    }
}
