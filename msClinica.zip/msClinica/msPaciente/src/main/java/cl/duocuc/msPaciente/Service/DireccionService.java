package cl.duocuc.msPaciente.Service;

public class DireccionService {

}
