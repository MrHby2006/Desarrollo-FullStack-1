package cl.duocuc.msPaciente.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duocuc.msPaciente.Model.Contacto;

@Repository
public interface ContactoRepository extends JpaRepository<Contacto, Integer> {
    Optional<Contacto> findByPacienteId(Integer id);
}
