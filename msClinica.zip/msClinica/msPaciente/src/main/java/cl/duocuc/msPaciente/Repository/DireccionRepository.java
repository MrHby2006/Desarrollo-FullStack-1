package cl.duocuc.msPaciente.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duocuc.msPaciente.Model.Direccion;

@Repository
public interface DireccionRepository extends JpaRepository<Direccion, Integer> {
    Optional<Direccion> findByPacienteId(Integer id);

}
