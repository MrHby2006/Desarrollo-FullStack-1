package cl.duocuc.msPaciente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPacienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
