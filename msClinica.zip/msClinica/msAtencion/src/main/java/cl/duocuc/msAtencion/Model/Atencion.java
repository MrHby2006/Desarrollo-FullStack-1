package cl.duocuc.msAtencion.Model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table
public class Atencion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private String diagnostico;

    @Column(nullable = false)
    private Date fechaAtencion;

    @ManyToOne
    @JoinColumn(name = "tipo_atencion_id", nullable = false)
    private TipoAtencion tipoAtencion;

    @Column(name = "paciente_id", nullable = false)
    private Integer pacienteId;

    @Column(name = "doctor_id", nullable = false)
    private Integer doctorId;
}
