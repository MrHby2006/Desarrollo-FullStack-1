package cl.duocuc.msAtencion.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duocuc.msAtencion.Model.TipoAtencion;

@Repository
public interface TipoAtencionRepository extends JpaRepository<TipoAtencion, Integer> {
    
}
