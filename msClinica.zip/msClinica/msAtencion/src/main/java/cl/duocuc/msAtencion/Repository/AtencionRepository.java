package cl.duocuc.msAtencion.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.duocuc.msAtencion.Model.Atencion;

@Repository
public interface AtencionRepository extends JpaRepository<Atencion, Integer> {
    List<Atencion> findByPacienteId(Integer pacienteId);

    List<Atencion> findByDoctorId(Integer doctorId);
}
