package cl.duocuc.msAtencion.dto;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AtencionDTO {
    private Integer id;
    private String diagnostico;
    private Date fechaAtencion;
    private DoctorDTO doctor;
    private PacienteDTO paciente;
    private String tipoAtencion;
}
