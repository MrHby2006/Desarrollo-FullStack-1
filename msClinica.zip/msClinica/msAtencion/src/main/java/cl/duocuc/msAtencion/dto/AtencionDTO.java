package cl.duocuc.msAtencion.dto;

import java.sql.Date;

import cl.duocuc.msAtencion.Model.TipoAtencion;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AtencionDTO {
    private Integer id;
    private Date fechaAtencion;
    private String diagnostico;
    private PacienteDTO paciente;
    private MedicoDTO medico;
    private TipoAtencion tipoAtencion;
}
