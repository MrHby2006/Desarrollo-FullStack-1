package cl.duocuc.msAtencion.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.msAtencion.Repository.AtencionRepository;

@Service
public class AtencionService {
    @Autowired
    private AtencionRepository repo;

    
}
