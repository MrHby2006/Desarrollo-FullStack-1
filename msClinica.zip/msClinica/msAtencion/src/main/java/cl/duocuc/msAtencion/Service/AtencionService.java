package cl.duocuc.msAtencion.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.duocuc.msAtencion.Client.DoctorCliente;
import cl.duocuc.msAtencion.Client.PacienteCliente;
import cl.duocuc.msAtencion.Model.Atencion;
import cl.duocuc.msAtencion.Repository.AtencionRepository;
import cl.duocuc.msAtencion.dto.AtencionDTO;
import cl.duocuc.msAtencion.dto.DoctorDTO;
import cl.duocuc.msAtencion.dto.PacienteDTO;

@Service
public class AtencionService {
    @Autowired
    private AtencionRepository repo;

    @Autowired
    private DoctorCliente doctorCliente;

    @Autowired
    private PacienteCliente pacienteCliente;

    public List<cl.duocuc.msAtencion.Model.Atencion> getAll() {
        return repo.findAll();
    }

    public Atencion save(Atencion atencion) {
        return repo.save(atencion);
    }

    public Atencion getById(Integer id) {
        return repo.findById(id).orElseThrow(() -> new RuntimeException("Atencion no encontrada"));
    }

    public AtencionDTO buscarAtencionDTO(Integer id){
        Atencion atencion = repo.findById(id).orElseThrow(() -> new RuntimeException("Atencion no encontrada"));

        DoctorDTO doctor = doctorCliente.getDoctorById(atencion.getDoctorId());
        PacienteDTO paciente = pacienteCliente.getPacienteDTO(atencion.getPacienteId());

        AtencionDTO dto = new AtencionDTO();
        dto.setId(atencion.getId());
        dto.setFechaAtencion(atencion.getFechaAtencion());
        dto.setDiagnostico(atencion.getDiagnostico());
        dto.setDoctor(doctor);
        dto.setPaciente(paciente);
        dto.setTipoAtencion(atencion.getTipoAtencion().getNombre());
        return dto;
    }
}
