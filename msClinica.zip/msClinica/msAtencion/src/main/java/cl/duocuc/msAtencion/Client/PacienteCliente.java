package cl.duocuc.msAtencion.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import cl.duocuc.msAtencion.dto.PacienteDTO;

@FeignClient(name = "msPaciente", url = "http://localhost:8081")
public interface PacienteCliente {

    @GetMapping("/api/v1/pacientes/dto/{id}")
    PacienteDTO getPacienteDTO(@PathVariable ("id") Integer id);
}
