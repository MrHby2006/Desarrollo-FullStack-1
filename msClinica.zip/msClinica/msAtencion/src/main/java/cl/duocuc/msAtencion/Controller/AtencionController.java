package cl.duocuc.msAtencion.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.duocuc.msAtencion.Model.Atencion;
import cl.duocuc.msAtencion.Service.AtencionService;
import cl.duocuc.msAtencion.dto.AtencionDTO;

@RequestMapping("/api/v1/atencion")
@RestController
public class AtencionController {
    @Autowired
    private AtencionService service;

    @GetMapping
    public ResponseEntity<List<Atencion>> getAll() {
        List<Atencion> atenciones = service.getAll();

        if(atenciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }else {
            return ResponseEntity.ok(atenciones);
        }
    }

    @PostMapping
    public ResponseEntity<Atencion> save(@RequestBody Atencion atencion) {
        try{
            service.save(atencion);
            return ResponseEntity.ok(atencion);
        }catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<Atencion> buscarPorId(@RequestAttribute Integer id) {
        try{
            Atencion atencion = service.getById(id);
            return ResponseEntity.ok(atencion);
        }catch(Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/atencionCompleta/{id}")
    public ResponseEntity<AtencionDTO> buscarAtencionCompleta(@PathVariable Integer id){
        try{
            return ResponseEntity.ok(service.buscarAtencionDTO(id));
        }catch(Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}
