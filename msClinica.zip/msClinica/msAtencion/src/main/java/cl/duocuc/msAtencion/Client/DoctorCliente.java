package cl.duocuc.msAtencion.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import cl.duocuc.msAtencion.dto.DoctorDTO;

@FeignClient(name = "msDoctores", url = "http://localhost:8082")
public interface DoctorCliente {

    @GetMapping("/api/v1/doctor/dto/{id}")
    DoctorDTO getDoctorById(@PathVariable ("id") Integer id);
}
