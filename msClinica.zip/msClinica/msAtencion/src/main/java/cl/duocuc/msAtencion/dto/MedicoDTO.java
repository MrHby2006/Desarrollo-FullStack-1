package cl.duocuc.msAtencion.dto;

public class MedicoDTO {

}
