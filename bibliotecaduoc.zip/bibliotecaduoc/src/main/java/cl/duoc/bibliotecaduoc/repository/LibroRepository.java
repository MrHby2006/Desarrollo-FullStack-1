package cl.duoc.bibliotecaduoc.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import java.util.ArrayList;

import cl.duoc.bibliotecaduoc.model.Libro;

@Repository
public class LibroRepository {
    List<Libro> listaLibros = new ArrayList<>();

    public List<Libro> obtenerLibros(){
        return listaLibros;
    }

    public Libro guardarLibro(Libro libro){
        listaLibros.add(libro);
        return libro;
    }

    public Libro buscarPorId(int idBuscado){
        for (Libro libro : listaLibros){
            if (libro.getId() == idBuscado){
                return libro;
            }
        }
        return null;
    }

    public Libro buscarPorIsbn(String isbnBuscado){
        for (Libro libro : listaLibros){
            if (libro.getIsbn().equals(isbnBuscado)){
                return libro;
            }
        }
        return null;
    }

    public Libro actualizar(Libro libroActualizado){
        int posicion = 0;
        for (int i = 0 ; i < listaLibros.size(); i++){
            if (listaLibros.get(i).getId() == libroActualizado.getId()){
                posicion = i;
            }
        }
        listaLibros.set(posicion, libroActualizado);
        return libroActualizado;
    }

    public void eliminarLibro(int idEliminar){
        Libro libroAEliminar = buscarPorId(idEliminar);
        listaLibros.remove(libroAEliminar);
    }

    public LibroRepository(){
        listaLibros.add(new Libro(1, "1234", "Papelucho", "Marcela Paz", "Salamandra", "1997"));
        listaLibros.add(new Libro(2, "5678", "Cien años de soledad", "Gabriel García Márquez", "Sudamericana", "1967"));
        listaLibros.add(new Libro(3, "9012", "Don Quijote de la Mancha", "Miguel de Cervantes", "Francisco de Robles", "1605"));
        listaLibros.add(new Libro(4, "3456", "El Principito", "Antoine de Saint-Exupéry", "Reynal & Hitchcock", "1943"));
        listaLibros.add(new Libro(5, "7890", "Rayuela", "Julio Cortázar", "Editorial Sudamericana", "1963"));
        listaLibros.add(new Libro(6, "1122", "Crónica de una muerte anunciada", "Gabriel García Márquez", "La Oveja Negra", "1981"));
        listaLibros.add(new Libro(7, "3344", "La ciudad y los perros", "Mario Vargas Llosa", "Seix Barral", "1963"));
        listaLibros.add(new Libro(8, "5566", "Ficciones", "Jorge Luis Borges", "Sur", "1944"));
        listaLibros.add(new Libro(9, "7788", "Pedro Páramo", "Juan Rulfo", "Fondo de Cultura Económica", "1955"));
        listaLibros.add(new Libro(10, "9900", "La casa de los espíritus", "Isabel Allende", "Plaza & Janés", "1982"));
    }
}
